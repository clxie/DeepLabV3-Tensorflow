from libs.datasets.VOC12.image_reader import ImageReader
from libs.datasets.VOC12.utils import decode_labels, inv_preprocess, prepare_label

VOC_CATS = ['__background__', 'aeroplane', 'bicycle', 'bird', 'boat', 'bottle',
            'bus', 'car', 'cat', 'chair', 'cow', 'diningtable', 'dog', 'horse',
            'motorbike', 'person', 'pottedplant', 'sheep', 'sofa', 'train',
            'tvmonitor']